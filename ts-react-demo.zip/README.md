# 用 TypeScript 编写 React

> I have a ts
>
> I have a jsx
>
> eng~
>
> tsx

React是前端同学必须了解或掌握的框架之一

TypeScript是一个用过都说好的前端框架

你可以找到很好的React教程, 也可以找到很详细的TypeScript文档, 但是想找到两者结合的教程则不容易

这个demo就是带你一步一步打开 tsx 的大门



