/**
 *  React 的 基础组件
 */

import * as React from 'react';
// React 引入方式发生了变化

// 编写基础 react 组件
const BaseComponent = () => {
  return (
    <p> Hello component ! </p>
  );
}

export default BaseComponent;