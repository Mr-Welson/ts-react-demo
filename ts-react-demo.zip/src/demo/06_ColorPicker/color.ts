// 用接口定义对象的形状
export interface IColor {
  red: number;
  green: number;
  blue: number;
}