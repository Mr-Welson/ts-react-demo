import * as React from 'react';
import BaseComponent from './demo/01_BaseComponent/index';
import ReactProps from './demo/02_Props/index';
import ReactState from './demo/03_State/index';
import Input from './demo/04_Input/index';
import InputRefactor from './demo/05_InputRefactor/index';
import ColorPicker from './demo/06_ColorPicker/index';
import ColorPickerRefactor from './demo/07_ColorPickerRefactor/index';
import Sidebar from './demo/08_Sidebar/index';
import TableMock from './demo/09_TableMock/index';
import TableHttp from './demo/10_TableHttp/index';

import './App.css';

const routeList = [
  {
    value: '01',
    label: '基础组件',
    component: <BaseComponent />
  },
  {
    value: '02',
    label: 'props',
    component: <ReactProps name='admin' />
  },
  {
    value: '03',
    label: 'state：修改用户名',
    component: <ReactState />
  },
  {
    value: '04',
    label: '输入框01：使用按钮确认修改',
    component: <Input />
  },
  {
    value: '05',
    label: '输入框02：带状态的按钮',
    component: <InputRefactor />
  },
  {
    value: '06',
    label: '拾色器01',
    component: <ColorPicker />
  },
  {
    value: '07',
    label: '拾色器02: 使用slider组件',
    component: <ColorPickerRefactor />
  },
  {
    value: '08',
    label: '侧边栏',
    component: <Sidebar />
  },
  {
    value: '09',
    label: '表格mock',
    component: <TableMock />
  },
  {
    value: '10',
    label: '表格http',
    component: <TableHttp />
  },
]
class App extends React.Component {

  state = {
    active: '01'
  }

  changeMenu = (active: string) => {
    this.setState({
      active
    })
  }

  getContent = (active: string) => {
    const menuInfo = routeList.find(v => v.value === active);
    return (menuInfo!).component;
  }

  public render() {
    const { active } = this.state;
    return (
      <div className="root-wrapper">
        <ul className='menu-list'>
          { routeList.map(v => (
            <li key={v.value} onClick={() => this.changeMenu(v.value)}>
              {`Demo: ${v.label}`}
            </li>
          ))}
        </ul>
        <div className='content'>
          { this.getContent(active) }
        </div>
      </div>
    );
  }
}

export default App;
